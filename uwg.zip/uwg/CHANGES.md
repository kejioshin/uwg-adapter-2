# 1.0.0

- Initial commit of UWG adapter, based on https://github.com/indexexchange/app-nexus-adapter 
