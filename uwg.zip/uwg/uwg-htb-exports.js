//? if (FEATURES.GPT_LINE_ITEMS) {
shellInterface.UWGHtb = {
    render: SpaceCamp.services.RenderService.renderDfpAd.bind(null, 'UWGHtb')
};
//? }
